
alist = [10,20,30,5,6,4,47,8,45]
# append
alist.append(89)
print('After appending', alist)   # single value
alist.append(99)
print('After appending', alist)

# extend
alist.extend([67,78,89])  # passing multiple values
print('After extending ',alist)

# count
print(alist.count(10))

# insert(where to insert , what to insert)
# insert(index,value)
alist.insert(1, 1000)
print('After inserting ',alist)


alist[1] = 1000

# pop ( using index)
alist.pop(1)
print('after pop operation', alist)

# remove

alist.remove(10)
print("After remove method ",alist)


# sort  (in place)( ascending)
alist.sort()
print('after sorting ',alist)
# descendin order
alist.sort(reverse=True)
print('after sorting ',alist)

#reverse (in place)
alist.reverse()
print('after reversing',alist)

