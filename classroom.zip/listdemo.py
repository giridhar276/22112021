
alist = [10,20,45,43,65,4346,5]

print(alist)
# list slicing
print(alist[0:4])
print(alist[::-1])


alist[0]  = 1000
print("AFTER replacing ",alist)


atup = (34,5,4,43,56)
atup[0] = 678
print('After replacing ',atup)






