name = "python"
name.



alist = [10,20,10,30,5,6,4,47,8,45]


for val in range(0,alist.count(10)):

    alist.remove(10)
print("After remove method ",alist)



print(1,2,sep="    ")

print("hello",end= " ")
print("python")