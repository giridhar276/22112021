## for with range()
for val in range(1,11):
    print(val)

for val in range(2,11,2):
    print(val)
    
for val in range(1,11,2):
    print(val)

# for with string
name = "python not equal to c"
for char in name:
    print(char)
for char in name.split(' '):
    print(char)


name = "python not equal to c"
output = name.split(" ")
for word in output:
    print(word)
    
# for with list
alist = ["python","c","java"]
for item in alist:
    print(item)
    

# for with dictionary
book = {"chap1":10 ,"chap2":20}

# display ONLY keys
for key in book.keys():
    print(key)
    
    
    
#display only values
for value in book.values():
    print(value)
    
print(book.items())
# read both key and value
for k,v in book.items():
    print("key  :", k)
    print("value:" , v)


