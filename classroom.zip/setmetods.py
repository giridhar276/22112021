



aset = {10,20,10,20,30,10,10,10,10}
bset = {30,30,30,30,30,40,50}
print(aset)
print(bset)

print(aset.union(bset))
print(aset.intersection(bset))
print(aset.issubset(bset))
print(aset.issuperset(bset))


alist = [10,10,10,20,20]
output = set(alist)
print(output)


alist = [10,10,10,20,20]
output = set(alist)   # converting to set
print(list(output))   # converting to list
