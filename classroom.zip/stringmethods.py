

name = "python programming"

print(name)

print(name.capitalize())
print(name.upper())
print(name.lower())
print(name.startswith('p'))
# replace
print(name.replace('python', 'scala') )
# string is immutable
print(name)

print(name.count('p'))
print(name.count('prog'))

print(name.isupper())
print(name.islower())
print(name.isalpha())

print(name.split(" "))

aname = "python,perl,ruby,scala"
print(aname.split(","))



bname = " python  "
print(len(bname))  # 9
print(len(bname.strip()))   # will remove whitespace at both the ends
print(len(bname.rstrip()))  # at right side
print(len(bname.lstrip()))  # at left side






a,b = 10,20
if a < b :
    print("B is largest")
    print('Still inside if')
else:
    print('A is largest')
    print('still inside else part')
    
    
name = "python programming"
if name.isupper():
    print("string is upper")
else:
    print("STRING IS LOWER")
    

if name.startswith('py'):
    print("Its python programming")
else:
    print('its something else')






