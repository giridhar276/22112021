

book = {"chap1":10 ,"chap2":20 ,"chap1":1000}
print(book)
#print(book[0])
print(book['chap1'])


info  = {1:2,3:4,5:6}

book = {"chap1":[10,"UK"] ,"chap2":[20,"US"] ,"chap3":[50,"AUS"]}

print(book)
print(book['chap1'][1])

# only keys
print(book.keys())
# only values
print(book.values())
# pairs
print(book.items())   # list of tuple

#print(book['chap6'])
print(book.get('chap1'))


book1 = {"chap3":30 , "chap4":40}
book.update(book1)

print(book)





