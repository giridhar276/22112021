

# single line comment
#print(10,20,30)
#print("python","oracle")

# mutli line comment
'''
print(10,20,30)
print("python","oracle")
'''

"""
this is multi comment
"""

print(10,20,30)
print("python","oracle")


name ="python programming"
print("I love", name)

# string[start:stop:step]
print(name)
print(name[0])
print(name[1])

print(name[0:5])
print(name[7:10])

print(name[0:17:2])
print(name[0:17:4])
print(name[:])  # python programming
print(name[::]) # python programming
print(name[::-1]) #gnimmargorp nohtyp

































