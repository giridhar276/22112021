



name = " programming in python"

# method1
output = name.find('python')
if output != -1 :
    print("string exists")
    
# method2
if 'python' in name:
    print("string exists")

# method3

getcount = name.count('python')
if getcount != 0:
    print("string exists")
    

alist = [10,20,30,40]
# 1st method
getcount = alist.count(30)
if getcount != 0 :
    print("value exists")
    
# method2
if 30 in alist:
    print('value exists')






