import pymysql
import time

try:
    #connect database
    
    db = pymysql.connect(host="127.0.0.1",port=3306,user='root',password='india@123',database = 'wells') 
    #print(db)   # check the connection if successful or not
    if db:
        # for accessing the records
        cursor = db.cursor()
        # prepare your query
        query = "select * from realestate"
        #execute the query
        cursor.execute(query)
        #fetch the output
        for record in cursor.fetchall():
            print(record)   ## tuple
      
except pymysql.InterfaceError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except pymysql.IntegrityError as err:
    print(err)        
except (pymysql.MySQLError,pymysql.OperationalError) as err:
    print(err)
except Exception as err:
    print(err)