import pymysql
import time
import csv
import logging
logfile = time.strftime("%d_%b_%Y.log")
logging.basicConfig(level=logging.DEBUG, filename=logfile)
try:
    
    # creating file with today's timestamp
    filename = time.strftime("%d_%B_%Y.csv")  
    logging.info(filename + "created")
    
    #connect database
    fw = open(filename,"w",newline='')
    # converting file object to csv object
    writer = csv.writer(fw)
    db = pymysql.connect(host="127.0.0.1",port=3306,user='root',password='india@123',database = 'wells') 
    logging.debug("connected to database")
    #print(db)   # check the connection if successful or not
    if db:
        # for accessing the records
        cursor = db.cursor()
        logging.info("cursor created")
        # prepare your query
        query = "select * from realestate"
        logging.info(query + "executed")
        #execute the query
        cursor.execute(query)
        
        #fetch the output
        if len(cursor.fetchall()) == 0 :
            logging.warning("table is empty")
        for record in cursor.fetchall():
            #print(record)   ## tuple
            ### writing the output to the file
            writer.writerow(record)
    fw.close()
    db.close()
      
except pymysql.InterfaceError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except pymysql.IntegrityError as err:
    print(err)        
except (pymysql.MySQLError,pymysql.OperationalError) as err:
    print(err)
except Exception as err:
    print(err)